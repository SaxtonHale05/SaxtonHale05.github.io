<footer class="foot">
 <p>nämä ovat Tiinan tehtäviä, älä kopioi<p>
 <p>Tehtävät suorittanut Ville Jaanu</p>
</footer>
</body>
</html>